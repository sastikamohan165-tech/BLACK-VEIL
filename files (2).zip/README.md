# BLACK VEIL — Autonomous Defense Console (Full Stack)

Two folders, one system:

```
BlackVeil-FullStack/
├── blackveil-backend/     Node.js + Express + WebSocket API — the live data source
├── blackveil-frontend/    HTML/CSS/JS console — light-blue professional theme
└── README.md               you are here
```

The frontend no longer has any hardcoded/fake data. Every page fetches from the
backend's REST API, and a WebSocket feed pushes live agent/trust updates so the
dashboard visibly moves on its own — the way a real SOC console would.

## 1. Run the backend

```bash
cd blackveil-backend
npm install
npm start
```

You should see:

```
BLACK VEIL backend running on http://localhost:4000
REST API base:  http://localhost:4000/api
WebSocket feed: ws://localhost:4000/ws
```

The backend keeps one in-memory "live state" object (agents, sessions, threats,
trust scores...) and mutates it every 4 seconds — CPU/RAM drift, trust scores
moving, new alerts appearing — the same way real telemetry would arrive. Every
REST endpoint and the WebSocket both read from that same live object, so what
you see in the browser is genuinely coming from the server, not the page.

## 2. Run the frontend

Open the `blackveil-frontend` folder in VS Code and either:

- Right-click `index.html` → **Open with Live Server** (recommended — install
  the "Live Server" extension by Ritwick Dey if you don't have it), or
- Just double-click `index.html` to open it directly in a browser.

The frontend expects the backend at `http://localhost:4000`. If you open it as
a `file://` page or from a different dev server port, it will still find the
backend automatically (see `js/api.js` → `BV.config`) as long as the backend is
running on port 4000. Change `BV.config.apiBase` / `wsUrl` there if you move
the backend elsewhere.

> Optional one-process mode: the backend also serves the frontend directly.
> Copy (or symlink) `blackveil-frontend` next to `blackveil-backend` as a
> sibling folder — `server.js` already points `express.static` at
> `../blackveil-frontend` — then just visit `http://localhost:4000`.

## What's live vs. what's simulated

There is no external attacker, no real Neo4j/PostgreSQL/Redis, and no real
network sensors behind this — that infrastructure doesn't exist yet. What *is*
real:

- The frontend has **zero mock arrays**. Every number on screen came from an
  HTTP response or a WebSocket message, generated at request time by
  `blackveil-backend/src/state.js`.
- The backend's tick loop genuinely mutates its own state over time (agent
  trust drifting, new alerts firing, the dynamic password rotating), so
  refreshing the page or leaving it open shows real change, not a canned loop.
- Reports genuinely export **real files** — the PDF and Excel buttons on the
  Reports page call `GET /api/reports/:key/export?format=pdf|excel`, which
  builds an actual `.pdf` (via `pdfkit`) or `.xlsx` (via `exceljs`) from the
  live state at that moment and streams it down as a download.

To wire this up to a *real* security stack, replace the contents of
`state.js`'s tick loop and getters with calls into your actual telemetry
sources (Neo4j driver, log pipeline, IDS/EDR feeds, your auth provider) — the
REST/WebSocket contract the frontend expects is unchanged either way.

## Design

Light-blue professional theme: soft ink-on-white panels, glassmorphism cards,
a blue → cyan gradient brand mark, floating gradient "blobs" and a fine grid
in the background, and a full custom SVG icon set (see `js/icons.js`) instead
of emoji/unicode glyphs, used throughout the sidebar, panel headers, list rows
and cards. Typography: Rajdhani for headers, IBM Plex Sans for body copy, IBM
Plex Mono for telemetry/IDs/timestamps.

## Folder details

**blackveil-backend/**
- `server.js` — entry point, mounts REST routes + WebSocket, starts the tick loop
- `src/state.js` — the one live state object + all read models (one per page)
- `src/routes.js` — REST endpoints, one per dashboard section
- `src/export.js` — real PDF (pdfkit) / Excel (exceljs) file generation
- `src/ws.js` — WebSocket broadcast of live agent/trust updates

**blackveil-frontend/**
- `index.html` — layout shell + all 19 page sections (unchanged structure)
- `css/style.css` — light-blue professional design system
- `js/icons.js` — inline SVG icon set
- `js/charts.js` — canvas chart engine (line, gauge, heatmap, force graph)
- `js/api.js` — REST client + WebSocket connection to the backend
- `js/app.js` — navigation + rendering, all sourced from `js/api.js`
